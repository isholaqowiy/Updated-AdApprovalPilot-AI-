# AdApprovalPilot AI

Invite-only Telegram Ads compliance bot. Built with `aiogram` 3.x (async,
long-polling), `SQLAlchemy` (async, PostgreSQL), and the Gemini API for
channel audits and autonomous compliance rewrites.

Deployed as a **Render Background Worker** — no webhook, no public port.

## Architecture notes

This version differs from a webhook/FastAPI design in one deliberate way:
it runs `Dispatcher.start_polling()` instead of exposing `/webhook` and
`/healthz` routes. Background Worker services on Render don't bind a
port, so polling is the correct fit and matches the deployment pattern
already used across your other bots on this platform.

## Local setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in real values
python main.py
```

## Deploying on Render

1. Push this repo to GitHub.
2. In Render, create a new Blueprint from `render.yaml` — it provisions
   the worker service and a PostgreSQL database together.
3. Set the `sync: false` env vars in the Render dashboard: `BOT_TOKEN`,
   `ADMIN_ID`, `GEMINI_API_KEY`.
4. Deploy. Logs stream to the Render dashboard (stdout logging is
   pre-configured in `app/core/logger.py`).

## Admin commands

| Command | Purpose |
|---|---|
| `/authorize_fix @channel owner_id` | Whitelist a channel for Bot Fix Mode |
| `/force_remove_bot @channel` | Force the bot to leave any channel |
| `/set_premium user_id [invoice_id]` | Manually grant premium (or wire to a Stripe/crypto webhook later) |

Approve/deny/disable/reset access happens via inline buttons on the
"Access Request" card the admin receives automatically.

## Known limitation: history-dependent scoring

Engagement ratio, posting consistency, content safety, and link hygiene
scoring in `app/services/audit_engine.py` currently use placeholder
heuristics. The Telegram Bot API can't read a channel's historical
message content — only metadata for chats it belongs to. To score real
message history, wire in an MTProto client (Telethon), the same approach
already used in Omar's signal-copying bot, and replace the placeholders
in `run_channel_audit()`.

## Monetization

`User.role`, `payment_status`, `invoice_id`, and `subscription_expires_at`
are already on the model. To go live with Stripe or crypto payments,
add a small webhook receiver (a separate lightweight Render Web Service,
since a Background Worker can't accept inbound HTTP) that updates these
same fields — no schema changes needed.
